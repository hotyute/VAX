#include "config.h"

bool quit = false;