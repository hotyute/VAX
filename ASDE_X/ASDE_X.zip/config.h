#ifndef CONFIG_H
#define CONFIG_H

extern bool quit;

#endif