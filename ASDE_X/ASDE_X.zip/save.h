#ifndef SAVE_H
#define SAVE_H

void save_info();
void read_info();

#endif
