#include "tempdata.h"
#include "constants.h"

LineVis debug_vis;
std::unordered_map<int, ClosureArea> closureAreas;
